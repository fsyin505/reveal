Based on the original reveal modal (https://github.com/zurb/reveal), which was an excellent starting point for adding a super light-weight modal function to a site.  
The minor drawback is that modal sizes wasn't responsively displayed for mobile or arbitrary screen sizes.

This fork converts it into responsive display by converting widths to percentages and hiding modal elements using display:none, instead of visibility:hidden

Copy contents of the .zip file and launch demo.html to try it. 

